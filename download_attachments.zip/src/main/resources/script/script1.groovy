
import com.sap.gateway.ip.core.customdev.util.Message;
import groovy.xml.MarkupBuilder
import java.text.SimpleDateFormat

Message processData(Message message) {

    def body = message.getBody(Reader)
    def props = message.getProperties()
    String regEx = props.get("regEx")
    String timeZone = props.get("timeZone")

    def xmlWriter = new StringWriter()
    def xmlBuilder = new MarkupBuilder(xmlWriter)

    def feed = new XmlSlurper()
                        .parse(body)
                        .declareNamespace(m: "http://schemas.microsoft.com/ado/2007/08/dataservices/metadata",
                                d: "http://schemas.microsoft.com/ado/2007/08/dataservices")
        
    xmlBuilder.Attachments {
        feed.entry.findAll {entry -> entry.'m:properties'.'d:Name'.text() ==~ regEx}
                  .each {entry ->
                    Attachment {
                        MessageGuid(entry.'m:properties'.'d:MessageGuid'.text())
    
                        Name(entry.'m:properties'.'d:Name'.text())
    
                        String ts_utc = entry.'m:properties'.'d:TimeStamp'.text()
                        String ts_client = date_convert(ts_utc, "yyyy-MM-dd'T'HH:mm:ss", "UTC",
                                            "yyyy-MM-dd'T'HH-mm-ss", timeZone)
                        TimeStamp(ts_client)
                        
                        PayloadPath(entry.content.@src.text())
                        
                        PayloadSize(entry.'m:properties'.'d:PayloadSize'.text())
                    }
                }
    }
    
    message.setBody(xmlWriter.toString())

   return message
}

String date_convert(String source_date, String source_date_format, String source_time_zone,
                            String target_date_format, String target_time_zone){
    SimpleDateFormat sdf = new SimpleDateFormat(source_date_format)
    sdf.setTimeZone(TimeZone.getTimeZone(source_time_zone))
    Date date = sdf.parse(source_date)
    TimeZone tz_target = TimeZone.getTimeZone(target_time_zone)
    return date.format(target_date_format, tz_target)
 }


Message client_TimeZone_to_UTC(Message message){
    
    def props = message.getProperties()
    String logEnd = props.get('logEnd')
    String logStart = props.get('logStart')
    String timeZone = props.get('timeZone')
    
    logEnd = date_convert(logEnd, "yyyy-MM-dd'T'HH:mm:ss", timeZone,
                                            "yyyy-MM-dd'T'HH:mm:ss", "UTC")
    logStart = date_convert(logStart, "yyyy-MM-dd'T'HH:mm:ss", timeZone,
                                            "yyyy-MM-dd'T'HH:mm:ss", "UTC")
    message.setProperty('logEnd', logEnd)
    message.setProperty('logStart', logStart)
    return message
}

